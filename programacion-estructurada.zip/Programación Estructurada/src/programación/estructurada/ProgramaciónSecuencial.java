/*
 * Chimaltenango, Julio de 2020
 * Paradigma de Programación Estructurada
 * Ejemplo de Estructura Secuencial
 * Programado: Edy Xicón
 */
package programación.estructurada;
/**
 *
 * @author Edy
 */
// Importa la libreria Scanner para poder ingresar datos.
import java.util.Scanner;
public class ProgramaciónSecuencial {
    // Inicio de la aplicación.
    public static void main(String[] args) {
        
        System.out.println("Ejemplo de Estructura Secuencial");
        // Se crea una instancia para de la libreria Scanner.        
        Scanner teclado = new Scanner(System.in);
        // Inicializa las variables a utilizar.        
        int num1, num2, suma, producto;
        
        // Solicita al usuario el ingreso de datos.        
        System.out.println("Ingrese el primer valor:");
        num1 = teclado.nextInt();
        
        System.out.println("Ingrese el segundo valor:");
        num2 = teclado.nextInt();
        
        // Almacena en la variable "suma" la suma de los dos números.         
        suma = num1 + num2;
       
        // Almacena en la variable "producto" el producto de los dos números.
        producto = num1 * num2;
        
        // Muestra los resultados por consola.        
        System.out.println("***La suma de los dos valores es:***");
        System.out.println(suma);
        System.out.println("**El producto de los valores es:**");
        System.out.println(producto);
    }
}
