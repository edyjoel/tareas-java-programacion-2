/*
 * Chimaltenango, Julio de 2020
 * Paradima de Programción Estructurada
 * Ejemplo de Estructura Condicional Simple
 * Programado: Edy Xicón
 */
package programación.estructurada;
/**
 *
 * @author Edy
 */
// Importa la libreria Scanner para poder ingresar datos.
import java.util.Scanner;
public class EstructuraCondicionalSimple {
    // Inicio de la aplicación.
    public static void main(String[] args) {
        
        System.out.println("Ejemplo de Estructura Condicional Simple");
        // Se crea una instancia para de la libreria Scanner. 
        Scanner teclado = new Scanner(System.in);
        
        // Inicializa la variable Flotante "sueldo"        
        float sueldo;
        
        // Solicita al usuario el ingreso de su sueldo        
        System.out.println("Ingrese el sueldo:");
        sueldo = teclado.nextFloat();
       
        /*
        * Valida que el usuario tenga un sueldo mayor a 3000. 
        * Si el sueldo es mayor a 3000 le notifica que debe abonar impuestos.
        */ 
        if( sueldo > 3000 ) {
            System.out.println("Esta persona debe abonar impuestos.");
        }
    }
}
