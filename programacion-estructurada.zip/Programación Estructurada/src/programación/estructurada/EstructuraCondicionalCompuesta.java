/*
 * Chimaltenango, Julio de 2020 
 * Paradigma de Programación Estructurada
 * Ejemplo de Estructura Condicional Compuesta
 * Programador: Edy Xicón
 */
package programación.estructurada;
/**
 *
 * @author Edy
 */
// Importa la libreria Scanner para poder ingresar datos.
import java.util.Scanner;
public class EstructuraCondicionalCompuesta {
    // Inicio de la aplicación.
    public static void main(String[] args) {
        
        System.out.println("Ejemplo de Estructura Condional Compuesta");
        // Se crea una instancia para de la libreria Scanner. 
        Scanner teclado = new Scanner(System.in);
        
        // Inicializa las variables      
        int num1, num2;
        
        // Solicita los datos al usuario        
        System.out.print("Ingrese primer valor:");
        num1 = teclado.nextInt();
        
        System.out.print("Ingrese segundo valor:");
        num2 = teclado.nextInt();
        
        /*
        * Valida que el variable "num1" sea mayor a la variable "num2". 
        * Si la variable "num1" es mayor muestra en consola el valor de la variable "num1".
        * Si la variable "num1" no es mayor muestra en consola el valor de la variable "num2".
        */
        if( num1 > num2 ) {
            System.out.println( num1 );
        }else {
            System.out.println( num2 );
        }
    }
}
